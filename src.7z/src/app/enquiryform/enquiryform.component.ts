import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl,Validator, Validators} from '@angular/forms';

@Component({
  selector: 'app-enquiryform',
  templateUrl: './enquiryform.component.html',
  styleUrls: ['./enquiryform.component.css']
})
export class EnquiryformComponent  {

  public myDetail:FormGroup;  //this is model name
  constructor()
  {
      this.myDetail=new FormGroup({
          name:new FormControl('bhumika',[Validators.required,Validators.minLength(4)]),
          contact:new FormControl('patil',Validators.required),
          
     }

      );
  }


  public onFormDataSubmit()
  {
      console.log("data" ,this.myDetail.value);
  }

}
