import { Component, OnInit } from '@angular/core';
import { PdfViewerModule } from 'ng2-pdf-viewer';


@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.css']
})
export class TrainingComponent implements OnInit {
  pdfSrc: string = '/assets/pdf/sample.pdf';


  constructor() { 

  }

  changePDF(): void {
    this.pdfSrc = '/assets/pdf/content.pdf';

  }
  ngOnInit() {

  }

}
