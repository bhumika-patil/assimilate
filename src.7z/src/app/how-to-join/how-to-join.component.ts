import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-join',
  templateUrl: './how-to-join.component.html',
  styleUrls: ['./how-to-join.component.css']
})
export class HowToJoinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
