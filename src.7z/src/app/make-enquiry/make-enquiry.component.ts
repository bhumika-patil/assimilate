import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl,Validator, Validators} from '@angular/forms';


@Component({
  selector: 'app-make-enquiry',
  templateUrl: './make-enquiry.component.html',
  styleUrls: ['./make-enquiry.component.css']
})
export class MakeEnquiryComponent {
  
}
