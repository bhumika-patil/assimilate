import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { TrainingComponent } from './training/training.component';
import { MaterialComponent } from './material/material.component';
import { DurationComponent } from './duration/duration.component';
import { HowToJoinComponent } from './how-to-join/how-to-join.component';
import { MakeEnquiryComponent } from './make-enquiry/make-enquiry.component';
import { RegisterComponent } from './register/register.component';
import { JobOpeningsComponent } from './job-openings/job-openings.component';
import { DownloadsComponent } from './downloads/downloads.component';
import {ReactiveFormsModule} from '@angular/forms';

import{ScheduleComponent} from './schedule/schedule.component';
import{FormGroup,FormControl,Validator, Validators} from '@angular/forms';
import { EnquiryformComponent } from './enquiryform/enquiryform.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TrainingComponent,
    MaterialComponent,
    DurationComponent,
    HowToJoinComponent,
    MakeEnquiryComponent,
    RegisterComponent,
    JobOpeningsComponent,
    DownloadsComponent,
    ScheduleComponent,
    EnquiryformComponent
     
  ],
  imports: [
    BrowserModule,
    PdfViewerModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [DownloadsComponent]
})
export class AppModule { }
